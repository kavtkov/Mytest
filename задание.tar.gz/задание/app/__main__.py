#!/usr/bin/env python3

from app.rest import main

main()
