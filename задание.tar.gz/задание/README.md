
#### Инструкция:
* install Flask `pip install flask`
* launch Flask REST API server `python -m app`
* launch unittests
  * classes: `python -m app.tests.utest_classes`
  * REST API: `python -m app.tests.utest_rest`

